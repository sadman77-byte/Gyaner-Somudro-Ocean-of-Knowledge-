document.addEventListener('DOMContentLoaded', function () {
    if (
        !(
            'CSS' in window &&
            CSS.hasOwnProperty('supports') &&
            CSS.supports('block-size', '1px') &&
            CSS.supports('selector(:where(*))') &&
            CSS.supports('gap', '1px')
        )
    ) {
        document.body.classList.add('is-unsupported-browser');
    }
});
